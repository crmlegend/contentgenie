<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ACR_Remote_Client {
  private $base;
  private $version;
  private $debug;

  public function __construct( $api_base, $plugin_version, $debug = true ) {
    $this->base    = untrailingslashit( $api_base );
    $this->version = $plugin_version;
    $this->debug   = (bool) $debug;
  }

  /* ------------------------
   * Internals / helpers
   * ------------------------ */
  private function log( $msg ) {
    if ( $this->debug ) error_log( '[ACR Remote] ' . $msg );
  }

  private function base_url() {
    return untrailingslashit( $this->base ?: ( defined('ACR_API_BASE') ? ACR_API_BASE : '' ) );
  }

  /**
   * Read provider API keys from plugin settings (or constants) and
   * attach them as headers so the server can use them.
   */
  private function provider_headers() {
    // Try options first (your settings page should save to these).
    // If you already store them under different option names, adjust here.
    $openai = get_option('acr_openai_api_key');
    $gemini = get_option('acr_gemini_api_key');

    // Allow hardcoding via constants if you want
    if ( empty( $openai ) && defined('ACR_OPENAI_API_KEY') ) {
      $openai = ACR_OPENAI_API_KEY;
    }
    if ( empty( $gemini ) && defined('ACR_GEMINI_API_KEY') ) {
      $gemini = ACR_GEMINI_API_KEY;
    }

    $h = array();
    if ( ! empty( $openai ) ) {
      $h['X-OpenAI-Key'] = trim( (string) $openai );
    }
    if ( ! empty( $gemini ) ) {
      $h['X-Gemini-Key'] = trim( (string) $gemini );
    }
    return $h;
  }

  // private function do_post( $url, $api_key, $payload, $timeout = 60 ) {
  //   $headers = array_merge(
  //     [
  //       'Authorization' => 'Bearer ' . trim( (string) $api_key ),
  //       'Content-Type'  => 'application/json',
  //       'Accept'        => 'application/json',
  //     ],
  //     $this->provider_headers()
  //   );

  //   $this->log( 'POST ' . $url );
  //   $res = wp_remote_post( $url, [
  //     'timeout' => (int) $timeout,
  //     'headers' => $headers,
  //     'body'    => wp_json_encode( (array) $payload ),
  //   ] );

  //   if ( is_wp_error( $res ) ) {
  //     $this->log( 'WP_Error: ' . $res->get_error_message() );
  //     return $res;
  //   }

  //   $code     = (int) wp_remote_retrieve_response_code( $res );
  //   $body_raw = (string) wp_remote_retrieve_body( $res );

  //   $this->log( 'HTTP ' . $code );
  //   $this->log( 'Body: ' . $body_raw );

  //   if ( $code === 401 || $code === 403 ) {
  //     return new WP_Error( 'acr_invalid_key', 'API key invalid (HTTP ' . $code . ')' );
  //   }
  //   // if ( $code !== 200 ) {
  //   //   return new WP_Error( 'acr_server', 'Server error (HTTP ' . $code . ')' );
  //   // }


  //   if ( $code !== 200 ) {
  //     // Try to surface server error details
  //     $err = 'Server error (HTTP ' . $code . ')';
  //     $decoded = json_decode( $body_raw, true );
  //     if ( is_array( $decoded ) ) {
  //       if ( ! empty( $decoded['detail'] ) && is_string( $decoded['detail'] ) ) {
  //         $err .= ': ' . $decoded['detail'];
  //       } elseif ( ! empty( $decoded['message'] ) && is_string( $decoded['message'] ) ) {
  //         $err .= ': ' . $decoded['message'];
  //       }
  //     } elseif ( is_string( $body_raw ) && $body_raw !== '' ) {
  //       $err .= ': ' . $body_raw;
  //     }
  //     return new WP_Error( 'acr_server', $err );
  //   }
  //   $json = json_decode( $body_raw, true );
  //   if ( ! is_array( $json ) ) {
  //     return new WP_Error( 'acr_parse', 'Invalid JSON from server.' );
  //   }
  //   return $json;
  // }





  private function do_post( $url, $api_key, $payload, $timeout = 60 ) {
    // Validate URL early.
    $validated_url = wp_http_validate_url( $url );
    if ( ! $validated_url ) {
        return new WP_Error( 'acr_bad_url', 'Invalid remote URL.' );
    }

    // Compose headers (will redact Authorization in logs).
    $headers = array_merge(
        [
            'Authorization' => 'Bearer ' . trim( (string) $api_key ),
            'Accept'        => 'application/json',
            'Content-Type'  => 'application/json',
            'User-Agent'    => sprintf(
                '%s/%s; %s',
                defined('ACR_PLUGIN_NAME') ? ACR_PLUGIN_NAME : 'ACR',
                defined('ACR_PLUGIN_VERSION') ? ACR_PLUGIN_VERSION : '0.0.0',
                home_url()
            ),
        ],
        $this->provider_headers()
    );

    // Allow customization.
    if ( function_exists( 'apply_filters' ) ) {
        $headers = apply_filters( 'acr_http_headers', $headers, $validated_url, $payload );
    }

    $args = [
        'timeout'     => (int) $timeout,
        'headers'     => $headers,
        'sslverify'   => true,
        'redirection' => 5,
        'body'        => wp_json_encode( (array) $payload ),
    ];

    if ( function_exists( 'apply_filters' ) ) {
        $args['timeout'] = (int) apply_filters( 'acr_http_timeout', $args['timeout'], $validated_url );
        $args            = apply_filters( 'acr_http_request_args', $args, $validated_url, $payload );
    }

    // Safe logging (no secrets / huge payloads).
    $log_headers = $args['headers'];
    if ( isset( $log_headers['Authorization'] ) ) {
        $log_headers['Authorization'] = 'Bearer ********';
    }
    $this->log( 'POST ' . $validated_url );
    $this->log( 'Headers: ' . wp_json_encode( $log_headers ) );

    $max_attempts = function_exists( 'apply_filters' ) ? (int) apply_filters( 'acr_http_max_attempts', 2 ) : 2;
    $attempt      = 0;

    do {
        $attempt++;

        // Safer HTTP call.
        $res = wp_safe_remote_post( $validated_url, $args );

        if ( is_wp_error( $res ) ) {
            $this->log( 'WP_Error: ' . $res->get_error_message() );
            if ( $attempt < $max_attempts ) {
                // brief backoff
                if ( function_exists( 'wp_sleep' ) ) { wp_sleep( $attempt === 1 ? 1 : 2 ); } else { sleep( $attempt === 1 ? 1 : 2 ); }
                continue;
            }
            return new WP_Error( 'acr_http_request_failed', 'Request failed: ' . $res->get_error_message() );
        }

        $code     = (int) wp_remote_retrieve_response_code( $res );
        $body_raw = (string) wp_remote_retrieve_body( $res );

        $this->log( 'HTTP ' . $code );
        $this->log( 'Body (tail): ' . mb_substr( $body_raw, -500 ) );

        // if ( $code === 401 || $code === 403 ) {
        //     return new WP_Error( 'acr_invalid_key', 'API key invalid (HTTP ' . $code . ')' );
        // }



        if ( $code === 401 || $code === 403 ) {
          // Try to surface a friendly message from the server
          $msg = 'Unauthorized / trial exhausted (HTTP ' . $code . ')';
          $decoded = json_decode($body_raw, true);
          if ( is_array($decoded) ) {
              if ( !empty($decoded['message']) ) { $msg = $decoded['message']; }
              elseif ( !empty($decoded['detail']) ) { $msg = $decoded['detail']; }
          }
          return new WP_Error('acr_unauthorized', $msg);
      }



        if ( $code === 429 ) {
            $retry_after = (int) wp_remote_retrieve_header( $res, 'retry-after' );
            if ( $attempt < $max_attempts && $retry_after > 0 && $retry_after <= 30 ) {
                $this->log( '429 received. Retrying after ' . $retry_after . 's.' );
                if ( function_exists( 'wp_sleep' ) ) { wp_sleep( $retry_after ); } else { sleep( $retry_after ); }
                continue;
            }
            return new WP_Error( 'acr_rate_limited', 'Rate limit exceeded. Please try again later.' );
        }

        if ( $code >= 500 && $code <= 599 ) {
            if ( $attempt < $max_attempts ) {
                $this->log( 'Server 5xx. Retrying (attempt ' . ( $attempt + 1 ) . ').' );
                if ( function_exists( 'wp_sleep' ) ) { wp_sleep( min( 5, 1 << ( $attempt - 1 ) ) ); } else { sleep( min( 5, 1 << ( $attempt - 1 ) ) ); }
                continue;
            }
        }

        if ( $code !== 200 ) {
            $err     = 'Server error (HTTP ' . $code . ')';
            $decoded = json_decode( $body_raw, true );
            if ( is_array( $decoded ) ) {
                if ( ! empty( $decoded['detail'] ) && is_string( $decoded['detail'] ) ) {
                    $err .= ': ' . $decoded['detail'];
                } elseif ( ! empty( $decoded['message'] ) && is_string( $decoded['message'] ) ) {
                    $err .= ': ' . $decoded['message'];
                }
            } elseif ( $body_raw !== '' ) {
                $err .= ': ' . mb_substr( trim( $body_raw ), 0, 500 );
            }
            return new WP_Error( 'acr_server', $err );
        }

        $json = json_decode( $body_raw, true );
        if ( ! is_array( $json ) ) {
            $json_err = function_exists( 'json_last_error_msg' ) ? json_last_error_msg() : 'Unknown JSON error';
            return new WP_Error( 'acr_parse', 'Invalid JSON from server: ' . $json_err );
        }

        if ( function_exists( 'apply_filters' ) ) {
            $json = apply_filters( 'acr_http_response', $json, $res, $validated_url, $payload );
        }
        return $json;

    } while ( $attempt < $max_attempts );
}









  
  /* ------------------------
   * Public API
   * ------------------------ */

   public function verify_key( $raw_key ) {
    $raw_key = trim( (string) $raw_key );

    // Build endpoint URL
    if ( defined('ACR_API_VERIFY_URL') && ACR_API_VERIFY_URL ) {
        $url = ACR_API_VERIFY_URL;
    } else {
        $base = $this->base_url();
        if ( empty( $base ) ) {
            return new WP_Error( 'acr_config', 'API base URL not configured.' );
        }
        $url = untrailingslashit( $base ) . '/api/key/verify/';
    }

    // The verify endpoint expects the key in the body (no Authorization header)
    $res = wp_remote_post( $url, array(
        'timeout'   => 15,
        'headers'   => array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ),
        'body'      => wp_json_encode( array( 'key' => $raw_key ) ),
        'sslverify' => true,
    ) );

    if ( is_wp_error( $res ) ) {
        return $res;
    }

    $code = (int) wp_remote_retrieve_response_code( $res );
    $body = (string) wp_remote_retrieve_body( $res );

    if ( 200 !== $code ) {
        return new WP_Error( 'acr_verify_failed', 'Verification failed (HTTP ' . $code . ')' );
    }

    $json = json_decode( $body, true );
    if ( ! is_array( $json ) ) {
        return new WP_Error( 'acr_parse', 'Invalid JSON from verify endpoint.' );
    }

    // Expect: { ok: true/false, plan: "...", key_prefix: "..." }
    return $json;
}



  public function generate( $api_key, array $payload ) {
    $api_key = trim( (string) $api_key );
    $base = $this->base_url();
    if ( empty( $base ) ) {
      return new WP_Error( 'acr_config', 'API base URL not configured.' );
    }
    $url = $base . '/v1/generate/content';
    return $this->do_post( $url, $api_key, (array) $payload, 120 );
  }



  public function blog_preview( $api_key, array $payload ) {
    $api_key = trim( (string) $api_key );
    $base = $this->base_url();
    if ( empty( $base ) ) {
      return new WP_Error( 'acr_config', 'API base URL not configured.' );
    }
    $url = $base . '/v1/blog/preview';
    $json = $this->do_post( $url, $api_key, $payload, 120 );
    if ( is_wp_error( $json ) ) return $json;
    if ( ! isset( $json['html'] ) ) {
      return new WP_Error( 'acr_server_shape', 'Server did not return preview HTML.' );
    }
    return $json;
  }

  public function process_elementor( $api_key, array $payload ) {
    $api_key = trim( (string) $api_key );
    $base = $this->base_url();
    if ( empty( $base ) ) {
      return new WP_Error( 'acr_config', 'API base URL not configured.' );
    }
    $url = $base . '/v1/generate/content';
    $json = $this->do_post( $url, $api_key, $payload, 180 );
    if ( is_wp_error( $json ) ) return $json;
    if ( ! isset( $json['elementor'] ) || ! is_array( $json['elementor'] ) ) {
      return new WP_Error( 'acr_server_shape', 'Server did not return updated Elementor JSON.' );
    }
    return $json;
  }
}
