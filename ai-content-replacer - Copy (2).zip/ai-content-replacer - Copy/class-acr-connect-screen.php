<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Genie Control Panel</title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles for the blue theme and subtle animation */
        :root {
            --primary-blue: #3B82F6; /* Sky-500 / Blue-500 */
            --light-blue: #DBEAFE; /* Blue-100 */
            --dark-blue: #1E40AF; /* Blue-800 */
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc; /* Light gray background, typical of WP admin areas */
            /* Crucial Fix: Remove min-h-screen and unnecessary centering on body 
               to allow it to fit naturally within the WordPress content frame. */
            padding: 0;
            margin: 0;
        }

        /*
           CRUCIAL FIX: The main card now uses w-full and a contained width (max-w-6xl) 
           but the primary container in WP is the admin screen itself. We use 
           margin: 0 auto; on the wrapper if we want to ensure it's contained 
           when viewed outside the WP environment, but inside WP, just w-full is enough.
        */
        #genie-app {
            width: 100%; 
            max-width: 100%;
        }

        /* Style the step icon line */
        .step-container .step-indicator.active::after {
            content: '';
            position: absolute;
            top: 2.5rem; /* Below the icon circle */
            left: 1.15rem; /* Centered with the circle */
            width: 2px;
            /* Dynamically setting height for the line to connect the next step */
            height: calc(100% - 2.5rem); 
            background-color: #E5E7EB; 
            z-index: 0;
        }
        /* Hide the line after the last step */
        #step-3 .step-indicator::after {
            content: none;
        }

        /* Gradient for the main card title */
        .title-gradient {
            background: linear-gradient(90deg, var(--dark-blue) 0%, var(--primary-blue) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* Custom styling for the Score Circle */
        .score-circle {
            position: relative;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            /* Setting progress for 85/100 -> 306deg */
            background: radial-gradient(white 60%, transparent 61%), 
                        conic-gradient(var(--primary-blue) 306deg, #E5E7EB 0deg); 
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 32px;
            color: var(--dark-blue);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); /* Stronger, more professional shadow */
        }

        /* Hide content until expanded */
        .step-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out;
        }
        .step-content.expanded {
            max-height: 250px; 
        }
    </style>
</head>
<body class="p-0">

    <!-- Main Content Card (Fills the WP Content Area) -->
    <div id="genie-app" class="w-full bg-white shadow-lg rounded-lg overflow-hidden border border-gray-200">
        
        <!-- Header Section -->
        <div class="p-6 bg-sky-50 border-b border-blue-100 flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-extrabold title-gradient">Content Genie Control Panel</h1>
                <p class="text-sm text-gray-500 mt-1">Hello! Let's generate and optimize your next piece of high-performing content.</p>
            </div>
            <!-- Status Pill for quick visibility -->
            <span class="inline-flex items-center rounded-full bg-red-100 px-3 py-1 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-200">
                Status: Action Required
            </span>
        </div>

        <!-- Two-Column Body Layout -->
        <div class="lg:flex p-8 gap-12">
            
            <!-- LEFT COLUMN: Content Generation Steps -->
            <div class="lg:w-7/12">
                <h2 class="text-xl font-bold text-gray-700 mb-6 border-b pb-2">Your Content Generation Workflow</h2>
                
                <!-- Step 1: Define Topic and Keywords (Completed) -->
                <div id="step-1" class="step-container relative mb-4 p-4 rounded-xl bg-white hover:bg-gray-50 transition duration-300 border border-gray-100">
                    <div class="flex items-start cursor-pointer" onclick="toggleStep(1)">
                        <div class="step-indicator active relative z-10 w-8 h-8 flex-shrink-0 bg-blue-500 rounded-full flex items-center justify-center shadow-md">
                            <svg class="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" /></svg>
                        </div>
                        <div class="ml-4 flex-1">
                            <h3 class="text-lg font-semibold text-gray-800">1. Define Topic and Keywords</h3>
                            <p class="text-xs text-blue-600 font-medium">Completed: Topic defined and keyword research finished.</p>
                        </div>
                        <span class="text-gray-400 text-sm transform transition duration-300" id="arrow-1">▼</span>
                    </div>
                    
                    <div id="step-content-1" class="step-content">
                        <p class="text-sm text-gray-600 mt-3 border-t pt-3">
                            Current Target Keywords: "Genie Marketing," "AI Content," "SEO Strategy." Everything looks good!
                        </p>
                        <button class="mt-3 text-sm font-medium text-blue-600 hover:text-blue-800 transition duration-150 border border-transparent hover:border-blue-200 p-1 rounded" onclick="alertUser('Reviewing existing keywords.')">
                            Review Keyword List &rarr;
                        </button>
                    </div>
                </div>

                <!-- Step 2: Generate Draft (Action Required) -->
                <div id="step-2" class="step-container relative mb-4 p-4 rounded-xl bg-blue-50 shadow-md transition duration-300 border border-blue-200">
                    <div class="flex items-start cursor-pointer" onclick="toggleStep(2)">
                        <div class="step-indicator relative z-10 w-8 h-8 flex-shrink-0 bg-blue-600 rounded-full flex items-center justify-center shadow-md animate-pulse">
                            <span class="text-sm font-bold text-white">2</span>
                        </div>
                        <div class="ml-4 flex-1">
                            <h3 class="text-lg font-bold text-blue-800">2. Generate and Review Draft Content</h3>
                            <p class="text-xs text-red-500 font-bold">Action Required: Initiate AI drafting.</p>
                        </div>
                        <span class="text-gray-400 text-sm transform transition duration-300" id="arrow-2">▼</span>
                    </div>

                    <div id="step-content-2" class="step-content">
                        <p class="text-sm text-gray-700 mt-3 border-t border-blue-100 pt-3">
                            Ready to create a draft based on your keywords. Choose your desired word count and style below.
                        </p>
                        <div class="flex gap-4 mt-3">
                            <label class="text-sm text-gray-600">
                                Word Count: 
                                <select class="ml-2 border border-gray-300 rounded p-1 text-sm">
                                    <option>500 Words</option>
                                    <option>1000 Words</option>
                                </select>
                            </label>
                            <label class="text-sm text-gray-600">
                                Tone: 
                                <select class="ml-2 border border-gray-300 rounded p-1 text-sm">
                                    <option>Professional</option>
                                    <option>Casual</option>
                                </select>
                            </label>
                        </div>
                        <button class="mt-4 text-sm font-medium bg-blue-600 text-white py-2 px-4 rounded-full shadow-lg hover:bg-blue-700 transition duration-150" onclick="alertUser('Generating content draft. This will take a moment.')">
                            Start Content Generation &rarr;
                        </button>
                    </div>
                </div>
                
                <!-- Step 3: Optimize and Publish (Pending) -->
                <div id="step-3" class="step-container relative mb-4 p-4 rounded-xl bg-white hover:bg-gray-50 transition duration-300 border border-gray-100">
                    <div class="flex items-start cursor-pointer" onclick="toggleStep(3)">
                        <div class="step-indicator relative z-10 w-8 h-8 flex-shrink-0 bg-gray-300 rounded-full flex items-center justify-center shadow-md">
                            <span class="text-sm font-bold text-gray-600">3</span>
                        </div>
                        <div class="ml-4 flex-1">
                            <h3 class="text-lg font-semibold text-gray-800">3. Optimize and Publish</h3>
                            <p class="text-xs text-gray-500">Pending: Final review and publishing to your site.</p>
                        </div>
                        <span class="text-gray-400 text-sm transform transition duration-300" id="arrow-3">▼</span>
                    </div>

                    <div id="step-content-3" class="step-content">
                        <p class="text-sm text-gray-600 mt-3 border-t pt-3">
                            This final step ensures maximum SEO performance, including image optimization, link checks, and final publishing to the WordPress editor.
                        </p>
                        <button class="mt-3 text-sm font-medium text-gray-400 border border-gray-300 py-1 px-3 rounded cursor-not-allowed" disabled>
                            Go to Optimization Editor &rarr;
                        </button>
                    </div>
                </div>

                <!-- Main CTA Button -->
                <div class="mt-8">
                    <button id="main-cta" class="bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-xl transition duration-300 transform hover:scale-[1.01] uppercase tracking-wider"
                        onclick="handleMainCta()">
                        I'm Stuck, Guide Me Through Step 2
                    </button>
                </div>
            </div>

            <!-- RIGHT COLUMN: Score & Health -->
            <div class="lg:w-5/12 mt-8 lg:mt-0 p-6 bg-blue-50 rounded-xl shadow-inner border border-blue-100">
                
                <h2 class="text-lg font-bold text-blue-700 mb-6 border-b pb-3 border-blue-200">AI Content Health & SEO Score</h2>

                <!-- Score Visualization -->
                <div class="flex flex-col items-center justify-center mb-8">
                    <div class="score-circle mb-3">
                        85
                    </div>
                    <p class="text-sm font-medium text-gray-600 mt-2">Target SEO Score: 90+</p>
                    <p class="text-xs text-blue-500 font-medium">Achieve high search visibility with optimized content.</p>
                </div>

                <!-- Benefits List (Content focused) -->
                <div class="space-y-4">
                    <h3 class="text-base font-semibold text-blue-700 mb-3">What Content Genie Guarantees:</h3>
                    <ul class="grid grid-cols-2 gap-x-4 gap-y-3">
                        <li class="flex items-center text-sm text-gray-700">
                            <span class="mr-2 text-blue-500 font-extrabold">&#10003;</span> High Keyword Density
                        </li>
                        <li class="flex items-center text-sm text-gray-700">
                            <span class="mr-2 text-blue-500 font-extrabold">&#10003;</span> 100% Originality Check
                        </li>
                        <li class="flex items-center text-sm text-gray-700">
                            <span class="mr-2 text-blue-500 font-extrabold">&#10003;</span> Improved Readability
                        </li>
                        <li class="flex items-center text-sm text-gray-700">
                            <span class="mr-2 text-blue-500 font-extrabold">&#10003;</span> Schema Markup Ready
                        </li>
                    </ul>
                </div>
            </div>
            
        </div>
        
        <!-- Custom Alert Box -->
        <div id="custom-alert" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
            <div class="bg-white p-6 rounded-lg shadow-2xl max-w-sm w-full transform scale-95 transition-all duration-300" id="alert-content">
                <p id="alert-message" class="text-gray-700 text-center mb-4"></p>
                <button onclick="closeAlert()" class="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200">OK</button>
            </div>
        </div>
    </div>

    <script>
        // --- JavaScript for Interactivity ---

        /**
         * Custom alert function (since native alert() is not allowed)
         * @param {string} message The message to display.
         */
        function alertUser(message) {
            const alertBox = document.getElementById('custom-alert');
            document.getElementById('alert-message').textContent = message;
            alertBox.classList.remove('hidden');
            alertBox.classList.add('flex');
            // Animate in
            document.getElementById('alert-content').classList.remove('scale-95');
            document.getElementById('alert-content').classList.add('scale-100');
        }

        /**
         * Closes the custom alert modal.
         */
        function closeAlert() {
            const alertBox = document.getElementById('custom-alert');
            // Animate out
            document.getElementById('alert-content').classList.remove('scale-100');
            document.getElementById('alert-content').classList.add('scale-95');

            setTimeout(() => {
                alertBox.classList.remove('flex');
                alertBox.classList.add('hidden');
            }, 300); // Match transition duration
        }

        /**
         * Toggles the visibility of a step's detailed content, implementing an accordion.
         * @param {number} stepNumber The number of the step to toggle.
         */
        function toggleStep(stepNumber) {
            const content = document.getElementById(`step-content-${stepNumber}`);
            const arrow = document.getElementById(`arrow-${stepNumber}`);

            if (content && arrow) {
                if (content.classList.contains('expanded')) {
                    // Collapse
                    content.classList.remove('expanded');
                    content.style.maxHeight = '0';
                    arrow.style.transform = 'rotate(0deg)';
                } else {
                    // Expand: Collapse all others first for a clean accordion effect
                    for(let i = 1; i <= 3; i++) {
                        const otherContent = document.getElementById(`step-content-${i}`);
                        const otherArrow = document.getElementById(`arrow-${i}`);
                        if (i !== stepNumber && otherContent && otherContent.classList.contains('expanded')) {
                             otherContent.classList.remove('expanded');
                             otherContent.style.maxHeight = '0';
                             otherArrow.style.transform = 'rotate(0deg)';
                        }
                    }

                    content.classList.add('expanded');
                    // Set max-height dynamically for smooth transition 
                    // Use a conservative large number to ensure all content fits, as scrollHeight can be tricky with complex content
                    content.style.maxHeight = '500px'; 
                    arrow.style.transform = 'rotate(180deg)';
                }
            }
        }
        
        /**
         * Handles the main call-to-action button click.
         */
        function handleMainCta() {
            alertUser("Guiding you to Step 2. Please choose your content settings and click 'Start Content Generation'.");
            toggleStep(2);
        }

        // Initialize the Step 2 as expanded on load to prompt action.
        window.onload = () => {
             // Use a slight delay to ensure scrollHeight is calculated correctly after CSS application
             setTimeout(() => toggleStep(2), 100); 
        };
    </script>
</body>
</html>
